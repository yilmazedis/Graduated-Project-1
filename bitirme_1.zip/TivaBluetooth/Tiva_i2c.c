/*
 * Tiva_i2c.c
 *
 *  Created on: 13 Mar 2018
 *      Author: MuhammetTayyip
 */
#include <stdint.h>
#include <stdbool.h>
#include "Tiva_i2c.h"
#include "tm4c123gh6pm.h"
#include "hw_i2c.h"
#include "hw_memmap.h"
#include "hw_types.h"
#include "hw_gpio.h"
#include "i2c.h"
#include "sysctl.h"
#include "gpio.h"
#include "pin_map.h"

//A6-->SCL I2C1
//A7-->SDA I2C1

void initI2C0_ADXL345(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C0);
    SysCtlPeripheralReset(SYSCTL_PERIPH_I2C0);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
    GPIOPinConfigure(GPIO_PB2_I2C0SCL);
    GPIOPinConfigure(GPIO_PB3_I2C0SDA);
    GPIOPinTypeI2CSCL(GPIO_PORTB_BASE, GPIO_PIN_2);
    GPIOPinTypeI2C(GPIO_PORTB_BASE, GPIO_PIN_3);
    I2CMasterInitExpClk(I2C0_BASE, SysCtlClockGet(), false);
    HWREG(I2C0_BASE + I2C_O_FIFOCTL) = 80008000;
}

uint8_t readI2C0_ADXL345(uint16_t device_address, uint16_t device_register)
{
    I2CMasterSlaveAddrSet(I2C0_BASE, device_address, false);
    I2CMasterDataPut(I2C0_BASE, device_register);
    I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_SINGLE_SEND);
    while(I2CMasterBusy(I2C0_BASE));
    I2CMasterSlaveAddrSet(I2C0_BASE, device_address, true);
    I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_SINGLE_RECEIVE);
    while(I2CMasterBusy(I2C0_BASE));
    return( I2CMasterDataGet(I2C0_BASE));
}

void writeI2C0_ADXL345(uint16_t device_address, uint16_t device_register, uint8_t device_data)
{
    I2CMasterSlaveAddrSet(I2C0_BASE, device_address, false);
    I2CMasterDataPut(I2C0_BASE, device_register);
    I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_BURST_SEND_START);
    while(I2CMasterBusy(I2C0_BASE));
    I2CMasterDataPut(I2C0_BASE, device_data);
    I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_BURST_RECEIVE_FINISH);
    while(I2CMasterBusy(I2C0_BASE));
}

void initI2C1_ADXL345(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C1);
    SysCtlPeripheralReset(SYSCTL_PERIPH_I2C1);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
    GPIOPinConfigure(GPIO_PA6_I2C1SCL);
    GPIOPinConfigure(GPIO_PA7_I2C1SDA);
    GPIOPinTypeI2CSCL(GPIO_PORTA_BASE, GPIO_PIN_6);
    GPIOPinTypeI2C(GPIO_PORTA_BASE, GPIO_PIN_7);
    I2CMasterInitExpClk(I2C1_BASE, SysCtlClockGet(), false);
    HWREG(I2C1_BASE + I2C_O_FIFOCTL) = 80008000;
}

uint8_t readI2C1_ADXL345(uint16_t device_address, uint16_t device_register)
{
    I2CMasterSlaveAddrSet(I2C1_BASE, device_address, false);
    I2CMasterDataPut(I2C1_BASE, device_register);
    I2CMasterControl(I2C1_BASE, I2C_MASTER_CMD_SINGLE_SEND);
    while(I2CMasterBusy(I2C1_BASE));
    I2CMasterSlaveAddrSet(I2C1_BASE, device_address, true);
    I2CMasterControl(I2C1_BASE, I2C_MASTER_CMD_SINGLE_RECEIVE);
    while(I2CMasterBusy(I2C1_BASE));
    return( I2CMasterDataGet(I2C1_BASE));
}

void writeI2C1_ADXL345(uint16_t device_address, uint16_t device_register, uint8_t device_data)
{
    I2CMasterSlaveAddrSet(I2C1_BASE, device_address, false);
    I2CMasterDataPut(I2C1_BASE, device_register);
    I2CMasterControl(I2C1_BASE, I2C_MASTER_CMD_BURST_SEND_START);
    while(I2CMasterBusy(I2C1_BASE));
    I2CMasterDataPut(I2C1_BASE, device_data);
    I2CMasterControl(I2C1_BASE, I2C_MASTER_CMD_BURST_RECEIVE_FINISH);
    while(I2CMasterBusy(I2C1_BASE));
}

void initI2C2_ADXL345(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C2);
    SysCtlPeripheralReset(SYSCTL_PERIPH_I2C2);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);
    GPIOPinConfigure(GPIO_PE4_I2C2SCL);
    GPIOPinConfigure(GPIO_PE5_I2C2SDA);
    GPIOPinTypeI2CSCL(GPIO_PORTE_BASE, GPIO_PIN_4);
    GPIOPinTypeI2C(GPIO_PORTE_BASE, GPIO_PIN_5);
    I2CMasterInitExpClk(I2C2_BASE, SysCtlClockGet(), false);
    HWREG(I2C2_BASE + I2C_O_FIFOCTL) = 80008000;
}

uint8_t readI2C2_ADXL345(uint16_t device_address, uint16_t device_register)
{
    I2CMasterSlaveAddrSet(I2C2_BASE, device_address, false);
    I2CMasterDataPut(I2C2_BASE, device_register);
    I2CMasterControl(I2C2_BASE, I2C_MASTER_CMD_SINGLE_SEND);
    while(I2CMasterBusy(I2C2_BASE));
    I2CMasterSlaveAddrSet(I2C2_BASE, device_address, true);
    I2CMasterControl(I2C2_BASE, I2C_MASTER_CMD_SINGLE_RECEIVE);
    while(I2CMasterBusy(I2C2_BASE));
    return( I2CMasterDataGet(I2C2_BASE));
}

void writeI2C2_ADXL345(uint16_t device_address, uint16_t device_register, uint8_t device_data)
{
    I2CMasterSlaveAddrSet(I2C2_BASE, device_address, false);
    I2CMasterDataPut(I2C2_BASE, device_register);
    I2CMasterControl(I2C2_BASE, I2C_MASTER_CMD_BURST_SEND_START);
    while(I2CMasterBusy(I2C2_BASE));
    I2CMasterDataPut(I2C2_BASE, device_data);
    I2CMasterControl(I2C2_BASE, I2C_MASTER_CMD_BURST_RECEIVE_FINISH);
    while(I2CMasterBusy(I2C2_BASE));
}

void initI2C3_ADXL345(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C3);
    SysCtlPeripheralReset(SYSCTL_PERIPH_I2C3);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD);
    GPIOPinConfigure(GPIO_PD0_I2C3SCL);
    GPIOPinConfigure(GPIO_PD1_I2C3SDA);
    GPIOPinTypeI2CSCL(GPIO_PORTD_BASE, GPIO_PIN_0);
    GPIOPinTypeI2C(GPIO_PORTD_BASE, GPIO_PIN_1);
    I2CMasterInitExpClk(I2C3_BASE, SysCtlClockGet(), false);
    HWREG(I2C3_BASE + I2C_O_FIFOCTL) = 80008000;
}

uint8_t readI2C3_ADXL345(uint16_t device_address, uint16_t device_register)
{
    I2CMasterSlaveAddrSet(I2C3_BASE, device_address, false);
    I2CMasterDataPut(I2C3_BASE, device_register);
    I2CMasterControl(I2C3_BASE, I2C_MASTER_CMD_SINGLE_SEND);
    while(I2CMasterBusy(I2C3_BASE));
    I2CMasterSlaveAddrSet(I2C3_BASE, device_address, true);
    I2CMasterControl(I2C3_BASE, I2C_MASTER_CMD_SINGLE_RECEIVE);
    while(I2CMasterBusy(I2C3_BASE));
    return( I2CMasterDataGet(I2C3_BASE));
}

void writeI2C3_ADXL345(uint16_t device_address, uint16_t device_register, uint8_t device_data)
{
    I2CMasterSlaveAddrSet(I2C3_BASE, device_address, false);
    I2CMasterDataPut(I2C3_BASE, device_register);
    I2CMasterControl(I2C3_BASE, I2C_MASTER_CMD_BURST_SEND_START);
    while(I2CMasterBusy(I2C3_BASE));
    I2CMasterDataPut(I2C3_BASE, device_data);
    I2CMasterControl(I2C3_BASE, I2C_MASTER_CMD_BURST_RECEIVE_FINISH);
    while(I2CMasterBusy(I2C3_BASE));
}

