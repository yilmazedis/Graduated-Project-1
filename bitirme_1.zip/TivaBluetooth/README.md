# TivaCBluetooth
Bluetooth files for Tiva C Launchpad
Tested on CCS
Board:TM4C123GXL
Bluetooth: HC05
