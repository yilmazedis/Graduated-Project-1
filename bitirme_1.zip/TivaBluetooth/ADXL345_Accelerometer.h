/*
 * ADXL345_Accelerometer.h
 *
 *  Created on: 13 Mar 2018
 *      Author: MuhammetTayyip
 */

#ifndef ADXL345_ACCELEROMETER_H_
#define ADXL345_ACCELEROMETER_H_

#define ADXL345_GRAVITY_EARTH  9.80665

void init_ADXL345_0_Accelerometer(void);
void init_ADXL345_1_Accelerometer(void);
void init_ADXL345_2_Accelerometer(void);
void init_ADXL345_3_Accelerometer(void);

void SetPowerMode_0(unsigned char powerMode);
void SetPowerMode_1(unsigned char powerMode);
void SetPowerMode_2(unsigned char powerMode);
void SetPowerMode_3(unsigned char powerMode);

int16_t getAcceleration_rawX_0();
int16_t getAcceleration_rawY_0();
int16_t getAcceleration_rawZ_0();

int16_t getAcceleration_rawX_1();
int16_t getAcceleration_rawY_1();
int16_t getAcceleration_rawZ_1();

int16_t getAcceleration_rawX_2();
int16_t getAcceleration_rawY_2();
int16_t getAcceleration_rawZ_2();

int16_t getAcceleration_rawX_3();
int16_t getAcceleration_rawY_3();
int16_t getAcceleration_rawZ_3();

int pitchFunction(double X,double Y,double Z);
int rollFunction(double Y,double Z);
#endif /* ADXL345_ACCELEROMETER_H_ */
